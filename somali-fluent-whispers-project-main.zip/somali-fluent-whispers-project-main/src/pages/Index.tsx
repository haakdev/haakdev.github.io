
import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Mail, Phone, MapPin, Github, Linkedin, Twitter, Code, Palette, Globe, Users, Award, Star } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="fixed top-0 w-full bg-white/10 backdrop-blur-md border-b border-white/20 z-50">
        <div className="container mx-auto px-6 py-4">
          <nav className="flex items-center justify-between">
            <div className="text-2xl font-bold text-white">
              <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                Portfolio
              </span>
            </div>
            <div className="hidden md:flex space-x-8">
              <a href="#home" className="text-white/80 hover:text-white transition-colors">Home</a>
              <a href="#about" className="text-white/80 hover:text-white transition-colors">About</a>
              <a href="#services" className="text-white/80 hover:text-white transition-colors">Services</a>
              <a href="#projects" className="text-white/80 hover:text-white transition-colors">Projects</a>
              <a href="#contact" className="text-white/80 hover:text-white transition-colors">Contact</a>
            </div>
            <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
              Get Started
            </Button>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section id="home" className="pt-20 pb-20 px-6">
        <div className="container mx-auto text-center">
          <div className="max-w-4xl mx-auto">
            <Badge className="mb-6 bg-purple-500/20 text-purple-300 border-purple-500/30">
              ✨ Welcome to My Portfolio
            </Badge>
            <h1 className="text-6xl md:text-8xl font-bold mb-6 bg-gradient-to-r from-white via-purple-200 to-pink-200 bg-clip-text text-transparent">
              Creative Developer
            </h1>
            <p className="text-xl md:text-2xl text-white/70 mb-8 leading-relaxed">
              Building exceptional digital experiences with modern technologies and creative solutions
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-lg px-8 py-6">
                View My Work
              </Button>
              <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10 text-lg px-8 py-6">
                Contact Me
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-6">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">About Me</h2>
            <p className="text-white/70 text-lg max-w-2xl mx-auto">
              Passionate developer with expertise in modern web technologies
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <Card className="bg-white/10 backdrop-blur-md border-white/20">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold text-white mb-4">My Journey</h3>
                  <p className="text-white/80 leading-relaxed mb-6">
                    With over 5 years of experience in web development, I specialize in creating 
                    beautiful, functional, and user-friendly applications. I'm passionate about 
                    clean code, modern design, and innovative solutions.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {['React', 'TypeScript', 'Node.js', 'Python', 'AWS', 'Docker'].map((skill) => (
                      <Badge key={skill} className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="grid grid-cols-2 gap-6">
              <Card className="bg-white/5 backdrop-blur-md border-white/10 text-center p-6">
                <Award className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                <h4 className="text-2xl font-bold text-white">50+</h4>
                <p className="text-white/70">Projects Completed</p>
              </Card>
              <Card className="bg-white/5 backdrop-blur-md border-white/10 text-center p-6">
                <Users className="w-8 h-8 text-pink-400 mx-auto mb-2" />
                <h4 className="text-2xl font-bold text-white">30+</h4>
                <p className="text-white/70">Happy Clients</p>
              </Card>
              <Card className="bg-white/5 backdrop-blur-md border-white/10 text-center p-6">
                <Star className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
                <h4 className="text-2xl font-bold text-white">5.0</h4>
                <p className="text-white/70">Average Rating</p>
              </Card>
              <Card className="bg-white/5 backdrop-blur-md border-white/10 text-center p-6">
                <Globe className="w-8 h-8 text-green-400 mx-auto mb-2" />
                <h4 className="text-2xl font-bold text-white">15+</h4>
                <p className="text-white/70">Countries Served</p>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 px-6">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Services</h2>
            <p className="text-white/70 text-lg max-w-2xl mx-auto">
              Comprehensive digital solutions tailored to your needs
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-md border-white/20 hover:scale-105 transition-transform duration-300">
              <CardHeader>
                <Code className="w-12 h-12 text-purple-400 mb-4" />
                <CardTitle className="text-white text-xl">Web Development</CardTitle>
                <CardDescription className="text-white/70">
                  Custom web applications built with modern frameworks and best practices
                </CardDescription>
              </CardHeader>
            </Card>
            
            <Card className="bg-gradient-to-br from-pink-500/20 to-red-500/20 backdrop-blur-md border-white/20 hover:scale-105 transition-transform duration-300">
              <CardHeader>
                <Palette className="w-12 h-12 text-pink-400 mb-4" />
                <CardTitle className="text-white text-xl">UI/UX Design</CardTitle>
                <CardDescription className="text-white/70">
                  Beautiful, intuitive designs that provide exceptional user experiences
                </CardDescription>
              </CardHeader>
            </Card>
            
            <Card className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 backdrop-blur-md border-white/20 hover:scale-105 transition-transform duration-300">
              <CardHeader>
                <Globe className="w-12 h-12 text-blue-400 mb-4" />
                <CardTitle className="text-white text-xl">Digital Solutions</CardTitle>
                <CardDescription className="text-white/70">
                  End-to-end digital transformation and consulting services
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 px-6">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Featured Projects</h2>
            <p className="text-white/70 text-lg max-w-2xl mx-auto">
              A showcase of my recent work and achievements
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map((project) => (
              <Card key={project} className="bg-white/10 backdrop-blur-md border-white/20 overflow-hidden hover:scale-105 transition-transform duration-300">
                <div className="h-48 bg-gradient-to-br from-purple-500 to-pink-500 relative">
                  <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                    <Code className="w-12 h-12 text-white" />
                  </div>
                </div>
                <CardHeader>
                  <CardTitle className="text-white">Project {project}</CardTitle>
                  <CardDescription className="text-white/70">
                    Modern web application with advanced features and beautiful design
                  </CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-6">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Get In Touch</h2>
            <p className="text-white/70 text-lg max-w-2xl mx-auto">
              Ready to start your next project? Let's discuss how I can help
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-2 gap-12">
              <Card className="bg-white/10 backdrop-blur-md border-white/20">
                <CardHeader>
                  <CardTitle className="text-white text-2xl mb-6">Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center space-x-4">
                    <Mail className="w-6 h-6 text-purple-400" />
                    <span className="text-white">hello@example.com</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <Phone className="w-6 h-6 text-purple-400" />
                    <span className="text-white">+1 (555) 123-4567</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <MapPin className="w-6 h-6 text-purple-400" />
                    <span className="text-white">San Francisco, CA</span>
                  </div>
                  
                  <div className="pt-6">
                    <h4 className="text-white font-semibold mb-4">Follow Me</h4>
                    <div className="flex space-x-4">
                      <Button size="icon" variant="outline" className="border-white/30 text-white hover:bg-white/10">
                        <Github className="w-5 h-5" />
                      </Button>
                      <Button size="icon" variant="outline" className="border-white/30 text-white hover:bg-white/10">
                        <Linkedin className="w-5 h-5" />
                      </Button>
                      <Button size="icon" variant="outline" className="border-white/30 text-white hover:bg-white/10">
                        <Twitter className="w-5 h-5" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-white/10 backdrop-blur-md border-white/20">
                <CardHeader>
                  <CardTitle className="text-white text-2xl">Send Message</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <input 
                    type="text" 
                    placeholder="Your Name" 
                    className="w-full p-3 bg-white/10 border border-white/20 rounded-md text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                  <input 
                    type="email" 
                    placeholder="Your Email" 
                    className="w-full p-3 bg-white/10 border border-white/20 rounded-md text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                  <textarea 
                    placeholder="Your Message" 
                    rows={4}
                    className="w-full p-3 bg-white/10 border border-white/20 rounded-md text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-purple-500 resize-none"
                  ></textarea>
                  <Button className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
                    Send Message
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-white/20">
        <div className="container mx-auto text-center">
          <p className="text-white/70">
            © 2024 Portfolio. Made with ❤️ using modern web technologies.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
